import requests
from bs4 import BeautifulSoup

# Set the URL and headers to mimic a browser request
url = 'https://simplewine.ru/catalog/vino/'
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
}

# try:
#     # Fetch the webpage content
#     response = requests.get(url, headers=headers)
#     response.raise_for_status()  # Check for HTTP errors

#     # Parse the HTML content
#     soup = BeautifulSoup(response.text, 'html5lib')

#     # Find all product containers (update the class based on actual HTML inspection)
#     # Example: product_containers = soup.find_all('div', class_='product-card')
#     product_containers = soup.find_all('div', class_='catalog-grid__item')
#     print(product_containers)
#     wines = []
#     for container in product_containers:
#         # Extract the wine name (adjust class or tag accordingly)
#         # Example: name_element = container.find('h3', class_='product-title')
#         name_element = container.find('a', class_='snippet-middle')
#         name = name_element.text.strip() if name_element else 'N/A'

#         # Extract the price (adjust class or tag accordingly)
#         # Example: price_element = container.find('div', class_='product-price')
#         price_element = container.find('span', class_='price')
#         price = price_element.text.strip() if price_element else 'N/A'

#         wines.append({'name': name, 'price': price})

#     # Print the results
#     for wine in wines:
#         print(f"Name: {wine['name']}, Price: {wine['price']}")

# except requests.exceptions.RequestException as e:
#     print(f"Request error: {e}")
# except Exception as e:
#     print(f"An error occurred: {e}")



# Here the user agent is for Edge browser on windows 10. You can find your browser user agent from the above given link.
r = requests.get(url=url, headers=headers)
soup = BeautifulSoup(r.content, 'html5lib') # If this line causes an error, run 'pip install html5lib' or install html5lib
print(soup.prettify())