import scrapy
from scrapy.exceptions import CloseSpider
from scrapy.http import HtmlResponse
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
import time
import re

class FlatsSpider(scrapy.Spider):
    name = 'flats'
    start_urls = [
        "https://www.cian.ru/cat.php?deal_type=rent&engine_version=2&is_by_homeowner=1&offer_type=flat&p=1&region=1&type=4"
    ]
    current_url = start_urls[0]
    custom_settings = {
        'FEED_FORMAT': 'json',
        'FEED_URI': 'cian.json',
        'DOWNLOAD_DELAY': 2,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 2,
        'RETRY_ENABLED': True,
        'RETRY_TIMES': 5,
        'RETRY_HTTP_CODES': [429, 500, 502, 503, 504],
        'AUTOTHROTTLE_ENABLED': True,
        'AUTOTHROTTLE_START_DELAY': 2,
        'AUTOTHROTTLE_MAX_DELAY': 10,
        'AUTOTHROTTLE_TARGET_CONCURRENCY': 1.0,
    }
    prev_page_number = 0

    def parse(self, response):
        try:
            page_number = int(response.url.split('&p=')[1].split('&')[0])
        except IndexError:
            page_number = 1

        if page_number >= self.prev_page_number:
            self.prev_page_number = page_number
        else:
            raise CloseSpider("Reached end of pages")

        additional_block = response.xpath('//div[@data-name="Suggestions"]')
        if additional_block:
            response = self.click_more_button()
            self.logger.info("Clicking more button to load additional content")

        # Extract and follow each flat's detail page link
        flat_links = response.xpath("//a[contains(@class, '_93444fe79c--media--9P6wN')]/@href").getall()
        for link in flat_links:
            yield response.follow(link, callback=self.parse_flat)

        # Pagination: follow next page
        next_page_number = page_number + 1
        next_page_url = self.current_url.replace(f"p={page_number}", f"p={next_page_number}")
        self.current_url = next_page_url
        self.logger.info(f"Following page number: {next_page_number}")
        yield response.follow(next_page_url, callback=self.parse)

    def parse_flat(self, response):
        item = {}

        # Extract address (okrug/raion information)
        address_lines = response.xpath("//*[contains(@class, 'a10a3f92e9--address--SMU25')]//text()").getall()
        item['okrug'] = address_lines[1].strip() if len(address_lines) > 1 else None
        item['raion'] = address_lines[2].strip() if len(address_lines) > 2 else None

        # Extract metro information and minutes from station
        metro = {}
        for elem in response.xpath("//*[contains(@class, 'a10a3f92e9--underground--pjGNr')]"):
            lines = elem.xpath(".//text()").getall()
            if len(lines) >= 2:
                try:
                    minutes = int(lines[1].split()[0])
                except Exception:
                    minutes = None
                metro[lines[0].strip()] = minutes
        item['metro'] = metro

        # Extract key-value pairs (e.g. area, floor, year built)
        info = {}
        for elem in response.xpath("//*[contains(@class, 'a10a3f92e9--container--tqDAE')]"):
            lines = [line.strip() for line in elem.xpath(".//text()").getall() if line.strip()]
            for i in range(0, len(lines), 2):
                if i + 1 < len(lines):
                    info[lines[i]] = lines[i+1]
        item['info'] = info

        # Extract price and convert to an integer
        price_text_list = response.xpath("//*[contains(@class, 'a10a3f92e9--amount--ON6i1')]//text()").getall()
        if price_text_list:
            price_text = " ".join(price_text_list)
            price_digits = re.sub(r"[^\d]", "", price_text)
            item['price'] = int(price_digits) if price_digits.isdigit() else None
        else:
            item['price'] = None

        # Extract title/description (rooms, area, etc.)
        title_lines = response.xpath("//*[contains(@class, 'a10a3f92e9--title--vlZwT')]//text()").getall()
        if title_lines:
            item['title'] = " ".join(title_lines).strip()

        # Extract living complex details
        living_complex = response.xpath("//*[contains(@class, 'a10a3f92e9--link--A5SdC')]/text()").get()
        item['living_complex'] = living_complex.strip() if living_complex else None

        # Extract flat details and offer details as key-value pairs
        flat_details = {}
        for elem in response.xpath("//*[contains(@class, '10a3f92e9--group--K5ZqN')]"):
            lines = [line.strip() for line in elem.xpath(".//text()").getall() if line.strip()]
            data = [line for line in lines if line not in ['О квартире', 'О доме', 'Подписаться на дом']]
            for i in range(0, len(data), 2):
                if i + 1 < len(data):
                    flat_details[data[i]] = data[i+1]
        item['flat_details'] = flat_details

        # --- Process rent details ---
        rent_details = {}
        # texts to skip (such as button labels)
        skip_texts = {"Следить за изменением цены", "Предложите свою цену"}
        for elem in response.xpath("//*[contains(@class, 'a10a3f92e9--item--n_zVq')]"):
            # Filter out empty and irrelevant texts
            lines = [line.strip() for line in elem.xpath(".//text()").getall() 
                     if line.strip() and line.strip() not in skip_texts]
            if not lines:
                continue

            # Check if this element includes a monthly price
            if any("/мес" in line for line in lines):
                price_line = next((line for line in lines if "/мес" in line), None)
                if price_line:
                    price_digits = re.sub(r"[^\d]", "", price_line)
                    if price_digits:
                        rent_details['price_per_month'] = int(price_digits)
            # If the element looks like key-value pairs (even number of items and at least 2)
            elif len(lines) >= 2 and len(lines) % 2 == 0:
                for i in range(0, len(lines), 2):
                    rent_details[lines[i]] = lines[i+1]
            # If none of the above, you might want to store the value under a general key
            else:
                rent_details['extra_info'] = lines[0]
        print(rent_details)
        item['rent_details'] = rent_details
        # --- End processing rent details ---

        yield item

    def click_more_button(self) -> HtmlResponse:
        driver = webdriver.Chrome()
        driver.get(self.current_url)
        time.sleep(5)
        try:
            accept_cookies_button = driver.find_element(
                By.XPATH,
                "//div[@data-name='CookiesNotification']//div[contains(@class, '_25d45facb5--button--CaFmg')]"
            )
            accept_cookies_button.click()
            time.sleep(2)
        except NoSuchElementException:
            pass

        # Click the "more" button until no more suggestions are available
        while True:
            try:
                more_button = driver.find_element(By.CLASS_NAME, '_93444fe79c--moreSuggestionsButtonContainer--h0z5t')
                more_button.click()
                time.sleep(5)
            except Exception:
                break

        body = driver.page_source
        url = driver.current_url
        driver.quit()
        return HtmlResponse(url=url, body=body, encoding='utf-8')
