import scrapy

class FlatItem(scrapy.Item):
    okrug = scrapy.Field()
    
    raion = scrapy.Field()
    
    metro = scrapy.Field()
    
    info = scrapy.Field()
    
    price = scrapy.Field()
    
    title = scrapy.Field()
    
    living_complex = scrapy.Field()
    
    flat_details = scrapy.Field()

    rent_details = scrapy.Field()



# import scrapy


# class ScrapyprojectItem(scrapy.Item):
#     # define the fields for your item here like:
#     # name = scrapy.Field()
#     pass